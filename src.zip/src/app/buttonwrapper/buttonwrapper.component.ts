import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';

@Component({
  selector: 'app-buttonwrapper',
  templateUrl: './buttonwrapper.component.html',
  styleUrls: ['./buttonwrapper.component.css'],
})
export class ButtonwrapperComponent implements OnInit {

  @Output() showResults: EventEmitter<boolean> = new EventEmitter<boolean>();

  displayedValue: any = 0;
  data: any = 0;
  firstValue=0;
  action: any;
  secondvalue: any = 0;
  display: any = 0;
  Arry: Array<any> = [];
  toAction: boolean=false;

  constructor() {}

  ngOnInit() {}

   Getvalue(value: any) {
    debugger
    this.displayedValue=value;
    if(!this.toAction){
      this.firstValue = value;
    }
else{
  this.secondvalue=value
}
//     this.firstValue = (message);
// this.secondvalue=message.display
 }
  

  calulatedata(message: any) {
    this.data = message;
  }
  operator(event: any) {
    this.displayedValue=''
    this.action = event.action;
    this.toAction=true
  }

  total(number: any) {
    this.displayedValue = number.total;
  }
  calulatetotal() {
  
    // const a = parseFloat(this.firstValue);
    // const b = parseFloat(this.secondvalue);

// console.log(a,b)
    // let result:any;
    // if (this.action === 'm') {
    //   result = a * b;
    // } else if (this.action === 'd') {
    //   result = a / b;
    // } else if (this.action === 'a') {
    //   result = a + b;
    // } else if (this.action === 's') {
    //   result = a - b;
    // }
    // this.firstValue = result;
    // this.displayedValue = result.toString();
  }
  resetCalculator() {
    this.displayedValue = 0;
  }
}
