import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.css'],
})
export class ActionComponent {
  @Output() actionData: any = new EventEmitter();
  @Output() number:any=new EventEmitter();
  @Output() showResults:  EventEmitter<boolean> = new EventEmitter<boolean>();

  display: any;
  result:any
  firstValue: any=0;
  action: any;

  operator(action: any) {
   this.actionData.emit(action)
  }
  calc(){
    this.showResults.emit(true)
  }

  resetCalculator() {
    this.display = '0';
  }

}
