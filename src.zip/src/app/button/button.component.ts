import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css'],
})
export class ButtonComponent {
  @Output() childButtonEvent = new EventEmitter();
  @Input() display: any = 0;

  pressNum(number: any) {
    if (this.display == 0) {
      this.display = number;
      this.childButtonEvent.emit(this.display);
    } else {
      this.display += number;
      this.childButtonEvent.emit(this.display);
    }
    this.childButtonEvent.emit(this.display);

    //  if (this.display == 0) {
    //   this.childButtonEvent.emit((this.display += number.toString()));
    // }
    // else {
    //   debugger
    //    this.display += number;
    //   this.childButtonEvent.emit(this.display)
    // }
  }
}
